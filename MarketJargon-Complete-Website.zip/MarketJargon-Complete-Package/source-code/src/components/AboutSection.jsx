import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Globe, 
  Users, 
  TrendingUp, 
  Award, 
  Zap, 
  Shield,
  Target,
  Sparkles,
  Star,
  CheckCircle
} from 'lucide-react';

const AboutSection = () => {
  const features = [
    {
      icon: Globe,
      title: 'Global Reach, Local Touch',
      description: 'We serve clients worldwide with deep understanding of local markets and cultural nuances.'
    },
    {
      icon: Users,
      title: 'Small Business Specialists',
      description: 'Dedicated to empowering small businesses and startups with enterprise-level marketing strategies.'
    },
    {
      icon: Shield,
      title: 'Transparent & Trustworthy',
      description: 'Real-time dashboards, clear reporting, and honest communication at every step.'
    },
    {
      icon: Award,
      title: 'Innovation & Experience',
      description: 'Cutting-edge strategies backed by years of proven results and industry expertise.'
    }
  ];

  const values = [
    'Customization over one-size-fits-all packages',
    'Transparency in pricing and performance',
    'Results-driven approach with measurable ROI',
    'Education and empowerment of our clients',
    'Continuous innovation and adaptation',
    'Partnership, not just service provision'
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-muted/20 to-background">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-6xl font-bold mb-6">
            <span className="luxury-text-gradient">Learn About Your New</span>
            <br />
            <span className="luxury-text-gradient">Marketing Team</span>
          </h2>
          
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            We set out with the goal of being the steady hand for business owners when they need to navigate marketing their business. It can be overwhelming, but not with us here every step of the way.
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-3xl font-bold mb-6">
                <span className="text-white">A Unique Marketing Approach</span>
                <br />
                <span className="text-white">That Unlocks Creativity</span>
              </h3>
              
              <p className="text-gray-300 leading-relaxed mb-6">
                The idea is for you to treat Market Jargon like your favorite burrito shop. You walk in and move down the line, choosing what looks delicious that day, whatever you crave most. Then you come back, and choose the exact same, or switch it up and try something different that may taste even better.
              </p>
              
              <p className="text-gray-300 leading-relaxed">
                Our appeal is that you can use your creativity combined with our experience to craft a personalized marketing plan that is very distinctive to you. We've learned over the years that setting yourself apart from the competition is the key when it comes to marketing, so we consistently take advantage of that. And it consistently works.
              </p>
            </div>

            {/* Core Values */}
            <div className="space-y-4">
              <h4 className="text-xl font-semibold text-brand-deep-blue mb-4">Our Core Values</h4>
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle className="w-5 h-5 text-brand-deep-blue flex-shrink-0" />
                  <span className="text-gray-300">{value}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Content - Features Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="grid gap-6"
          >
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="deli-card p-6">
                    <CardContent className="p-0">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-deep-blue/20 to-brand-cosmic-pink/20 border border-brand-deep-blue/30 flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-brand-deep-blue" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-white mb-2">
                            {feature.title}
                          </h4>
                          <p className="text-gray-300 text-sm leading-relaxed">
                            {feature.description}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Mission Statement */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Card className="luxury-card max-w-4xl mx-auto p-12">
            <CardContent className="p-0">
              <h3 className="text-2xl font-bold mb-6">
                <span className="luxury-text-gradient">Our Core Belief</span>
              </h3>
              
              <blockquote className="text-2xl font-medium text-gray-300 italic mb-6 leading-relaxed">
                "When you find Market Jargon, you find what you need."
              </blockquote>
              
              <p className="text-gray-400 leading-relaxed">
                This is the motivation behind everything that we do here. The research shows that the businesses that open up without the knowledge, tools, and customized strategy that we offer, are the same businesses that don't survive. We set out to change that, one company at a time.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;

