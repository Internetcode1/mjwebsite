import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, HelpCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

const Footer = () => {
  const faqs = [
    {
      question: "Do I have to sign up for a long-term package?",
      answer: "No, we pride ourselves on flexibility. You can select services à la carte, mix and match strategies, or adjust your choices anytime. Our goal is to adapt with your business as it grows and evolves."
    },
    {
      question: "Can you integrate your services with tools I already use?",
      answer: "Absolutely. Our team can seamlessly integrate chatbots, CRM systems, and marketing automation into your existing platforms, ensuring you maintain smooth, organized interactions with your customers."
    },
    {
      question: "I'm not sure which marketing strategies I need. Can you help?",
      answer: "Of course! We want to personalize your plan to fit your goals, challenges, and audience. We'll guide you through our menu, recommending strategies tailored specifically to deliver maximum impact for your business, based on what we've learned from past projects."
    }
  ];

  return (
    <footer className="bg-gradient-to-b from-background to-black border-t border-border">
      <div className="container mx-auto px-6 py-16">
        {/* FAQ and Satisfaction Guaranteed */}
        <div className="grid lg:grid-cols-2 gap-12 mb-12">
          {/* FAQ Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-white flex items-center gap-3">
                  <HelpCircle className="w-6 h-6 text-brand-deep-blue" />
                  Frequently Asked Questions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {faqs.map((faq, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="space-y-3"
                  >
                    <h4 className="font-semibold text-white text-lg">
                      {index + 1}. {faq.question}
                    </h4>
                    <p className="text-gray-300 leading-relaxed">
                      {faq.answer}
                    </p>
                    {index < faqs.length - 1 && (
                      <div className="border-b border-border/30 pt-3"></div>
                    )}
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Satisfaction Guaranteed Box */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex items-center justify-center"
          >
            <Card className="luxury-card text-center w-full">
              <CardContent className="p-8">
                <div className="w-24 h-24 mx-auto mb-6 rounded-xl bg-gradient-to-br from-brand-deep-blue to-brand-cosmic-pink flex items-center justify-center">
                  <CheckCircle className="w-12 h-12 text-white" />
                </div>
                
                <h4 className="text-3xl font-bold text-white mb-4">Satisfaction Guaranteed</h4>
                
                <div className="space-y-4 text-left max-w-lg mx-auto">
                  <div>
                    <h5 className="text-xl font-semibold text-white mb-2 flex items-center gap-2">
                      A Solid Pact <span className="text-2xl">👌</span>
                    </h5>
                    <p className="text-gray-300 leading-relaxed">
                      If we do not complete your project to your expectations, you receive a 100% refund without a question asked.
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-gray-300 leading-relaxed">
                      We do this job for the lightbulb reactions <span className="text-xl">💡</span> and breakthrough moments <span className="text-xl">🧠</span>. If we don't achieve these, we don't want to be paid. That's our promise.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Copyright with Privacy Policy and Terms */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center pt-8 border-t border-border"
        >
          <p className="text-gray-400 mb-2">
            © 2025 MarketJargon. All rights reserved.
          </p>
          <div className="flex items-center justify-center gap-6 text-sm">
            <a 
              href="#privacy" 
              className="text-gray-400 hover:text-brand-deep-blue transition-colors"
            >
              Privacy Policy
            </a>
            <span className="text-gray-600">•</span>
            <a 
              href="#terms" 
              className="text-gray-400 hover:text-brand-deep-blue transition-colors"
            >
              Terms of Service
            </a>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;

