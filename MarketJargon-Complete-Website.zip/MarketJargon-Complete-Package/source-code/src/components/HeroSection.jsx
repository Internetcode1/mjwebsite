import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Button } from './ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';
import mammothImage from '../assets/mammoth-cosmic.png';
import newLogoImage from '../assets/mammoth-logo-new.png';

const HeroSection = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);

  return (
    <section ref={containerRef} className="relative min-h-screen overflow-hidden cosmic-background">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Cosmic Orbs */}
        <motion.div
          className="absolute top-20 right-20 w-32 h-32 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(168, 75, 47, 0.3) 0%, transparent 70%)',
            y: useTransform(scrollYProgress, [0, 1], ["0%", "20%"])
          }}
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        <motion.div
          className="absolute bottom-32 left-20 w-24 h-24 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(33, 128, 141, 0.4) 0%, transparent 70%)',
            y: useTransform(scrollYProgress, [0, 1], ["0%", "30%"])
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Main Content */}
      <motion.div 
        className="relative z-10 container mx-auto px-6 pt-32 pb-20"
      >
        {/* Expanded Content Area */}
        <div className="text-center max-w-6xl mx-auto">
          {/* Main Headline - Expanded */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.6 }}
                className="text-6xl lg:text-8xl font-bold leading-tight"
              >
                <span className="text-white">Your Marketing</span>
                <br />
                <span className="text-white">Solutions,</span>
                <br />
                <span className="text-brand-warm-orange">Your Way</span>
              </motion.h1>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="flex items-center justify-center gap-3"
              >
                <div className="h-1 w-16 bg-gradient-to-r from-brand-deep-blue to-brand-cosmic-pink rounded-full" />
                <span className="text-lg font-medium text-brand-deep-blue tracking-wider">UNIQUE DELI-STYLE MARKETING</span>
                <div className="h-1 w-16 bg-gradient-to-r from-brand-cosmic-pink to-brand-deep-blue rounded-full" />
              </motion.div>
            </div>

            {/* Extended Description */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="space-y-4 max-w-4xl mx-auto"
            >
              <p className="text-xl text-gray-300 leading-relaxed">
                MarketJargon isn't one size fits all. You choose your favorite ingredients, just like when you get a sandwich made at the deli. Select exactly what works for you, and receive customized results.
              </p>
              <p className="text-lg text-gray-200 leading-relaxed">
                Your job is to provide a high quality product that is innovative and interesting. You focus on that, while we focus on marketing so that you grow.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;

