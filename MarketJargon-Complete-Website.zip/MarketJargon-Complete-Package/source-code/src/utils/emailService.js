// Email service for MarketJargon contact form
export const sendContactEmail = async (formData) => {
  try {
    // Using EmailJS service for reliable email delivery
    const emailData = {
      to_email: 'william@flowintofunnels.com',
      from_name: formData.name,
      from_email: formData.email,
      company: formData.company,
      website: formData.website,
      message: formData.message,
      subject: 'New MarketJargon Contact Form Submission',
      submission_time: new Date().toLocaleString()
    };

    // Alternative: Use Netlify Forms or similar service
    const response = await fetch('/.netlify/functions/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailData)
    });

    if (!response.ok) {
      // Fallback to mailto link if service fails
      const mailtoLink = `mailto:william@flowintofunnels.com?subject=New MarketJargon Contact Form Submission&body=
Name: ${formData.name}
Email: ${formData.email}
Company: ${formData.company}
Website: ${formData.website}

Message:
${formData.message}

Submitted at: ${new Date().toLocaleString()}`;
      
      window.location.href = mailtoLink;
      return { success: true, method: 'mailto' };
    }

    return { success: true, method: 'service' };
  } catch (error) {
    console.error('Email service error:', error);
    
    // Fallback to mailto
    const mailtoLink = `mailto:william@flowintofunnels.com?subject=New MarketJargon Contact Form Submission&body=
Name: ${formData.name}
Email: ${formData.email}
Company: ${formData.company}
Website: ${formData.website}

Message:
${formData.message}

Submitted at: ${new Date().toLocaleString()}`;
    
    window.location.href = mailtoLink;
    return { success: true, method: 'mailto' };
  }
};

