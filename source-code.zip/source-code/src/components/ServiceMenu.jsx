import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Search, 
  Share2, 
  Target, 
  BarChart3, 
  PenTool, 
  Mail, 
  Settings, 
  Award,
  Zap,
  TrendingUp,
  Users,
  Globe,
  Smartphone,
  MessageSquare,
  Eye,
  ArrowRight,
  Sparkles,
  Plus,
  Check,
  DollarSign,
  Monitor,
  FileText,
  Phone,
  Bot,
  Star,
  Shield
} from 'lucide-react';

const ServiceMenu = () => {
  const [selectedServices, setSelectedServices] = useState([]);
  const [currentStation, setCurrentStation] = useState(0);
  const [showPopup, setShowPopup] = useState(false);

  const deliStations = [
    {
      id: 'paid-ads',
      name: 'Paid Ads',
      emoji: '💰',
      subtitle: 'Immediate Results, Instant Sales',
      icon: DollarSign,
      color: 'from-green-500 to-emerald-600',
      services: [
        {
          id: 'google-ppc',
          name: 'Google PPC Ads',
          subtitle: 'Clicks That Convert Instantly',
          description: 'Achieve immediate visibility with Pay-Per-Click campaigns by capturing eager buyers who are actively searching for your product or service.',
          tagline: 'Fresh leads now.',
          icon: Search,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        }
      ]
    },
    {
      id: 'social-media',
      name: 'Social Media',
      emoji: '📱',
      subtitle: 'Attention-Grabbing Conversions',
      icon: Smartphone,
      color: 'from-pink-500 to-rose-600',
      services: [
        {
          id: 'facebook-ads',
          name: 'Facebook Ads',
          subtitle: 'Stop The Swipe',
          description: 'Turn casual browsers into loyal buyers. With captivating Facebook ads, you can pinpoint your ideal audience and deliver meaningful engagement.',
          tagline: 'Charm casual viewers.',
          icon: Share2,
          color: 'bg-gradient-to-br from-blue-600 to-blue-700'
        },
        {
          id: 'instagram-ads',
          name: 'Instagram Ads',
          subtitle: 'Visuals That Convert Into Sales',
          description: 'Engage visual-driven buyers rapidly. Designers craft Instagram ads with irresistible visuals and strategic messaging, creating instant connections and sales.',
          tagline: 'Visual power.',
          icon: Eye,
          color: 'bg-gradient-to-br from-purple-500 to-pink-500'
        },
        {
          id: 'tiktok-ads',
          name: 'TikTok Ads',
          subtitle: 'Rapid Viral Growth',
          description: 'Achieve explosive growth on the world\'s hottest social platform. We craft TikTok campaigns designed to generate viral buzz, rapidly converting Gen Z into customers.',
          tagline: 'Rapid growth.',
          icon: Zap,
          color: 'bg-gradient-to-br from-red-500 to-pink-500'
        },
        {
          id: 'twitter-ads',
          name: 'Twitter/X Ads',
          subtitle: 'Real-Time Engagement, Real-Time Sales',
          description: 'Dominate trending topics instantly. Strong Twitter/X ads strategically place your brand in live conversations, driving immediate attention and measurable results.',
          tagline: 'Real-time wins.',
          icon: MessageSquare,
          color: 'bg-gradient-to-br from-blue-400 to-blue-500'
        },
        {
          id: 'snapchat-ads',
          name: 'Snapchat Ads',
          subtitle: 'Youthful Impact',
          description: 'Capture the eyes of fast-moving digital natives. Our Snapchat campaigns create immediate buzz, delivering quick connections and rapid sales among the youngest audience.',
          tagline: 'Young buyers spend money, too.',
          icon: Sparkles,
          color: 'bg-gradient-to-br from-yellow-400 to-yellow-500'
        },
        {
          id: 'linkedin-ads',
          name: 'LinkedIn Ads',
          subtitle: 'Valuable B2B Leads',
          description: 'Directly connect with key decision-makers. Deliver precise LinkedIn campaigns that fill your sales pipeline with quality business driven leads.',
          tagline: 'Get in front of professionals.',
          icon: Users,
          color: 'bg-gradient-to-br from-blue-700 to-blue-800'
        },
        {
          id: 'pinterest-ads',
          name: 'Pinterest Ads',
          subtitle: 'Inspired Shoppers',
          description: 'Position your products exactly where buyers seek inspiration. Expertly done Pinterest campaigns attract highly motivated shoppers ready to take immediate action.',
          tagline: 'Pinpoint success.',
          icon: Target,
          color: 'bg-gradient-to-br from-red-600 to-red-700'
        }
      ]
    },
    {
      id: 'native-retargeting',
      name: 'Native & Retargeting',
      emoji: '🎯',
      subtitle: 'Subtle Yet Effective',
      icon: Target,
      color: 'from-orange-500 to-red-600',
      services: [
        {
          id: 'native-advertising',
          name: 'Native Advertising',
          subtitle: 'Ads That Feel Organic',
          description: 'Seamlessly blend your message into trusted content. Our targeted native advertising achieves higher engagement and genuine trust without feeling intrusive.',
          tagline: 'Blend in, stand out.',
          icon: Eye,
          color: 'bg-gradient-to-br from-green-500 to-green-600'
        },
        {
          id: 'retargeting',
          name: 'Retargeting',
          subtitle: 'New Conversions From Second Chances',
          description: 'Re-engage past visitors with precision retargeting. Remind customers about what they\'re missing out on, converting missed opportunities into sales.',
          tagline: 'Reclaim your leads.',
          icon: Target,
          color: 'bg-gradient-to-br from-orange-500 to-orange-600'
        }
      ]
    },
    {
      id: 'seo',
      name: 'SEO',
      emoji: '🌐',
      subtitle: 'Rise Above the Competition',
      icon: Globe,
      color: 'from-blue-500 to-cyan-600',
      services: [
        {
          id: 'technical-seo',
          name: 'Technical SEO',
          subtitle: 'Fast Website, Faster Results',
          description: 'Boost your website\'s rankings and conversions simultaneously. Technical SEO ensures smooth, lightning-fast user experiences that customers and search engines reward.',
          tagline: 'Speed up your success.',
          icon: Settings,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        },
        {
          id: 'local-seo',
          name: 'Local SEO',
          subtitle: 'Own Your Local Market',
          description: 'Secure the top spot in local searches. Our adept local SEO campaigns drive increased foot traffic, visibility, and immediate local leads and sales.',
          tagline: 'Be first in your community.',
          icon: Globe,
          color: 'bg-gradient-to-br from-green-500 to-green-600'
        },
        {
          id: 'google-business',
          name: 'Google Business Page',
          subtitle: 'Boost Your Local Presence Instantly',
          description: 'Take control of your local search visibility with an optimized Google Business Profile. We manage complete setup, maximize positive reviews, and improve indexing, which builds trust and attracts more local customers.',
          tagline: 'Enhance local credibility now.',
          icon: Star,
          color: 'bg-gradient-to-br from-yellow-500 to-yellow-600'
        },
        {
          id: 'ecommerce-seo',
          name: 'E-Commerce SEO',
          subtitle: 'Rank Higher, Sell More',
          description: 'Turn your online store into an organic revenue generator. Optimize your product listings, driving consistent rankings and more profits.',
          tagline: 'Make search engines your sales force.',
          icon: BarChart3,
          color: 'bg-gradient-to-br from-purple-500 to-purple-600'
        },
        {
          id: 'international-seo',
          name: 'International SEO',
          subtitle: 'Global Reach, Global Revenue',
          description: 'Confidently scale your brand worldwide. Position your site to dominate global search results, breaking borders and expanding your revenue streams.',
          tagline: 'Expand your global presence.',
          icon: Globe,
          color: 'bg-gradient-to-br from-cyan-500 to-cyan-600'
        },
        {
          id: 'enterprise-seo',
          name: 'Enterprise SEO',
          subtitle: 'Simplified and Scalable',
          description: 'Efficiently manage large-scale optimization. We expertly handle complex SEO requirements, ensuring dominant visibility and sustainable growth.',
          tagline: 'Innovate advanced scale and growth.',
          icon: TrendingUp,
          color: 'bg-gradient-to-br from-indigo-500 to-indigo-600'
        }
      ]
    },
    {
      id: 'content',
      name: 'Content',
      emoji: '📝',
      subtitle: 'Engage, Educate, Convert',
      icon: FileText,
      color: 'from-purple-500 to-indigo-600',
      services: [
        {
          id: 'strategic-content',
          name: 'Strategic Content Development',
          subtitle: 'Content Crafted for Authority',
          description: 'Every word needs to be designed to convert. Create commanding content that engages your audience, builds credibility, and drives measurable results.',
          tagline: 'Build trust = boost sales.',
          icon: PenTool,
          color: 'bg-gradient-to-br from-purple-500 to-purple-600'
        },
        {
          id: 'video-content',
          name: 'Video Content',
          subtitle: 'Convert Viewers Immediately',
          description: 'Capture your audience emotionally with compelling video content. Videos engage, resonate deeply, and drive sudden action.',
          tagline: 'Show viewers your value.',
          icon: Monitor,
          color: 'bg-gradient-to-br from-red-500 to-red-600'
        },
        {
          id: 'blog-management',
          name: 'Blog Management',
          subtitle: 'Traffic About You',
          description: 'Make your blog your strongest sales tool. We skillfully create and manage content that attracts qualified traffic for your brand while also converting visitors.',
          tagline: 'Blog smarter, sell more.',
          icon: FileText,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        },
        {
          id: 'whitepapers',
          name: 'Whitepapers',
          subtitle: 'Instant Authority, High-Quality Leads',
          description: 'Establish immediate credibility and generate quality leads consistently. Professionally crafted whitepapers position your brand as the industry\'s trusted solution.',
          tagline: 'Lead with confidence.',
          icon: FileText,
          color: 'bg-gradient-to-br from-gray-600 to-gray-700'
        },
        {
          id: 'ebook-creation',
          name: 'E-Book Creation',
          subtitle: 'Powerful Lead Magnets',
          description: 'Instantly showcase your expertise. Create persuasive E-Books that build authority and make people want to learn more about what you offer.',
          tagline: 'Downloadable growth.',
          icon: FileText,
          color: 'bg-gradient-to-br from-green-500 to-green-600'
        },
        {
          id: 'ugc-creation',
          name: 'UGC Creation',
          subtitle: 'Authenticity Converts',
          description: 'Leverage genuine customer voices. Generate powerful user-generated content to immediately build trust and boost conversions, turning customers into advocates.',
          tagline: 'Build authentic connections.',
          icon: Users,
          color: 'bg-gradient-to-br from-orange-500 to-orange-600'
        }
      ]
    },
    {
      id: 'direct-campaigns',
      name: 'Direct Campaigns',
      emoji: '📬',
      subtitle: 'Faster Response, Stronger Impact',
      icon: Mail,
      color: 'from-teal-500 to-cyan-600',
      services: [
        {
          id: 'influencer-marketing',
          name: 'Influencer Marketing',
          subtitle: 'Immediate Credibility',
          description: 'Amplify your brand through trusted voices. Connect your brand to influential figures who drive validity and measurable profitability.',
          tagline: 'Influence your market.',
          icon: Star,
          color: 'bg-gradient-to-br from-pink-500 to-pink-600'
        },
        {
          id: 'email-campaigns',
          name: 'Email Campaigns',
          subtitle: 'Precision-Engineered Emails',
          description: 'With us, every email is engineered for maximum engagement. Design personalized campaigns that consistently convert and nurture your leads into loyal customers.',
          tagline: 'Email just works.',
          icon: Mail,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        },
        {
          id: 'cold-calling',
          name: 'Cold Calling',
          subtitle: 'Hot Results',
          description: 'Transform cold leads into eager buyers. Expertly scripted calls by experienced closers will accelerate your sales pipeline.',
          tagline: 'Dialing that\'s dialed in.',
          icon: Phone,
          color: 'bg-gradient-to-br from-green-500 to-green-600'
        },
        {
          id: 'sms-campaigns',
          name: 'SMS Campaigns',
          subtitle: 'Quick Responses, Quick Sales',
          description: 'Achieving a rapid result always feels good. Concise SMS campaigns generate immediate engagement and profits.',
          tagline: 'Text your way into growth.',
          icon: MessageSquare,
          color: 'bg-gradient-to-br from-purple-500 to-purple-600'
        },
        {
          id: 'voicemail-campaigns',
          name: 'Voicemail Campaigns',
          subtitle: 'Persuasive Messages, Quick Action',
          description: 'Ensure your message drives callbacks. Voicemail campaigns deliver compelling messages that lead directly to conversations.',
          tagline: 'Speak to success.',
          icon: Phone,
          color: 'bg-gradient-to-br from-orange-500 to-orange-600'
        },
        {
          id: 'direct-mail',
          name: 'Direct Mail',
          subtitle: 'Firsthand Results',
          description: 'We craft direct mail pieces with our in-house copywriter, crafting attention grabbing messages that increase interest and drive quick action.',
          tagline: 'Make a beautiful first impression.',
          icon: Mail,
          color: 'bg-gradient-to-br from-red-500 to-red-600'
        }
      ]
    },
    {
      id: 'automation',
      name: 'Automation',
      emoji: '⚙️',
      subtitle: 'Seamless & Scalable',
      icon: Settings,
      color: 'from-gray-500 to-slate-600',
      services: [
        {
          id: 'chatbot-development',
          name: 'Chatbot Development',
          subtitle: 'Sales 24/7',
          description: 'Never miss a sales opportunity. Build intelligent chatbots that continuously engage visitors, capture leads, and drive sales at all times.',
          tagline: 'Automate your growth.',
          icon: Bot,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        },
        {
          id: 'crm-integration',
          name: 'CRM Integration',
          subtitle: 'Seamless Lead Management',
          description: 'Maximize your effectiveness by integrating your CRM and streamlining your sales pipeline.',
          tagline: 'Integration leads to acceleration.',
          icon: Settings,
          color: 'bg-gradient-to-br from-green-500 to-green-600'
        },
        {
          id: 'sales-funnels',
          name: 'Sales Funnels',
          subtitle: 'Constant Revenue Generation',
          description: 'Automated journeys that convert predictably. Well crafted funnels built to optimize reliably and deliver continuous sales.',
          tagline: 'Consistent success.',
          icon: TrendingUp,
          color: 'bg-gradient-to-br from-purple-500 to-purple-600'
        }
      ]
    },
    {
      id: 'branding',
      name: 'Branding',
      emoji: '🏷️',
      subtitle: 'Memorable & Profitable',
      icon: Award,
      color: 'from-yellow-500 to-orange-600',
      services: [
        {
          id: 'brand-positioning',
          name: 'Brand Positioning',
          subtitle: 'Clearly Stand Apart',
          description: 'Define and differentiate your brand strategically. Position your business to capture attention and increase awareness.',
          tagline: 'Your competitive advantage.',
          icon: Target,
          color: 'bg-gradient-to-br from-yellow-500 to-yellow-600'
        },
        {
          id: 'brand-experience',
          name: 'Brand Experience Design',
          subtitle: 'Transformation Into A Lifetime Customer',
          description: 'We create memorable interactions that build loyalty by designing fluid customer experiences. These experiences lead to ongoing engagement and deep customer retention.',
          tagline: 'A remarkable journey never stops.',
          icon: Star,
          color: 'bg-gradient-to-br from-pink-500 to-pink-600'
        },
        {
          id: 'reputation-management',
          name: 'Reputation Management',
          subtitle: 'Secure Your Image',
          description: 'Proactively manage your online reputation by safeguarding your brand trust to ensure customer preference.',
          tagline: 'Protect your brand.',
          icon: Shield,
          color: 'bg-gradient-to-br from-blue-500 to-blue-600'
        }
      ]
    }
  ];

  const toggleService = (serviceId) => {
    setSelectedServices(prev => 
      prev.includes(serviceId) 
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const isSelected = (serviceId) => selectedServices.includes(serviceId);

  return (
    <section id="menu" className="py-24 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-6xl font-bold mb-6">
            <span className="luxury-text-gradient">Your Perfect Blend</span>
          </h2>
          
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-8">
            Select exactly what your business needs from our premium marketing menu. Take your time and choose what would be the most helpful.
          </p>

          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            If you have any questions about what the best fit is for you, don't hesitate to reach out to us.
          </p>
        </motion.div>

        {/* Deli Counter Navigation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {deliStations.map((station, index) => (
              <motion.button
                key={station.id}
                onClick={() => setCurrentStation(index)}
                whileHover={{ scale: 1.08, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className={`px-8 py-4 rounded-2xl font-bold transition-all duration-300 flex items-center gap-3 border-2 ${
                  currentStation === index
                    ? 'bg-gradient-to-r from-brand-deep-blue to-brand-cosmic-pink text-white shadow-2xl border-brand-cosmic-pink/50 shadow-brand-cosmic-pink/20'
                    : 'bg-gradient-to-r from-gray-800/80 to-gray-700/80 text-gray-200 hover:from-gray-700/90 hover:to-gray-600/90 border-gray-600/50 hover:border-brand-cosmic-pink/30 hover:shadow-lg hover:shadow-brand-cosmic-pink/10'
                }`}
              >
                <span className="text-2xl drop-shadow-lg">{station.emoji}</span>
                <span className="text-lg">{station.name}</span>
              </motion.button>
            ))}
          </div>

          {/* Station Progress Indicator */}
          <div className="flex justify-center mb-8">
            <div className="flex gap-2">
              {deliStations.map((_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentStation
                      ? 'bg-brand-deep-blue scale-125'
                      : index < currentStation
                      ? 'bg-brand-cosmic-pink'
                      : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
          </div>
        </motion.div>

        {/* Current Station Display */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStation}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            {/* Station Header */}
            <div className="text-center mb-12">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className={`w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${deliStations[currentStation].color} flex items-center justify-center`}
              >
                <span className="text-4xl">{deliStations[currentStation].emoji}</span>
              </motion.div>
              
              <h3 className="text-3xl font-bold text-white mb-4">
                {deliStations[currentStation].name}
              </h3>
              
              <p className="text-xl text-brand-cosmic-pink font-semibold">
                {deliStations[currentStation].subtitle}
              </p>
            </div>

            {/* Services Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {deliStations[currentStation].services.map((service, index) => {
                const Icon = service.icon;
                const selected = isSelected(service.id);
                
                return (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ y: -5 }}
                    className="relative"
                  >
                    <Card className={`deli-card h-full cursor-pointer transition-all duration-300 ${
                      selected ? 'ring-2 ring-brand-cosmic-pink shadow-lg shadow-brand-cosmic-pink/20' : ''
                    }`}
                    onClick={() => toggleService(service.id)}
                    >
                      <CardContent className="p-6">
                        {/* Selection Indicator */}
                        <div className="absolute top-4 right-4">
                          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                            selected 
                              ? 'bg-brand-cosmic-pink border-brand-cosmic-pink' 
                              : 'border-gray-500 hover:border-brand-cosmic-pink'
                          }`}>
                            {selected && <Check className="w-5 h-5 text-white" />}
                          </div>
                        </div>

                        {/* Service Icon */}
                        <div className={`w-16 h-16 rounded-xl ${service.color} flex items-center justify-center mb-4`}>
                          <Icon className="w-8 h-8 text-white" />
                        </div>

                        {/* Service Info */}
                        <h4 className="text-xl font-bold text-white mb-2">
                          {service.name}
                        </h4>
                        
                        <h5 className="text-lg font-semibold text-brand-cosmic-pink mb-3">
                          {service.subtitle}
                        </h5>
                        
                        <p className="text-gray-300 text-sm leading-relaxed mb-4">
                          {service.description}
                        </p>
                        
                        <div className="flex items-center justify-between">
                          <em className="text-brand-deep-blue font-medium text-sm">
                            {service.tagline}
                          </em>
                          
                          <Button 
                            size="sm" 
                            className={`transition-all duration-300 ${
                              selected 
                                ? 'bg-brand-cosmic-pink hover:bg-brand-cosmic-pink/80' 
                                : 'bg-brand-deep-blue hover:bg-brand-deep-blue/80'
                            }`}
                          >
                            {selected ? (
                              <>
                                <Check className="w-4 h-4 mr-1" />
                                Added
                              </>
                            ) : (
                              <>
                                <Plus className="w-4 h-4 mr-1" />
                                Add
                              </>
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center mt-12">
              <Button
                onClick={() => setCurrentStation(Math.max(0, currentStation - 1))}
                disabled={currentStation === 0}
                className="bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                ← Previous Station
              </Button>

              <div className="text-center">
                <p className="text-gray-400 text-sm mb-2">
                  Station {currentStation + 1} of {deliStations.length}
                </p>
                <p className="text-brand-cosmic-pink font-semibold">
                  {selectedServices.length} items selected
                </p>
              </div>

              <Button
                onClick={() => setCurrentStation(Math.min(deliStations.length - 1, currentStation + 1))}
                disabled={currentStation === deliStations.length - 1}
                className="bg-brand-deep-blue hover:bg-brand-deep-blue/80 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next Station →
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Selected Items Summary */}
        {selectedServices.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mt-16"
          >
            <Card className="luxury-card">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6 text-center">
                  Your Marketing Design
                </h3>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                  {selectedServices.map(serviceId => {
                    const service = deliStations
                      .flatMap(station => station.services)
                      .find(s => s.id === serviceId);
                    
                    if (!service) return null;
                    
                    return (
                      <div
                        key={serviceId}
                        className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg"
                      >
                        <div className={`w-8 h-8 rounded-lg ${service.color} flex items-center justify-center flex-shrink-0`}>
                          <service.icon className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-gray-300 text-sm font-medium">
                          {service.name}
                        </span>
                        <button
                          onClick={() => toggleService(serviceId)}
                          className="ml-auto text-gray-400 hover:text-red-400 transition-colors"
                        >
                          ×
                        </button>
                      </div>
                    );
                  })}
                </div>
                
                <div className="text-center">
                  <Button 
                    className="premium-button text-lg px-8 py-4"
                    onClick={() => setShowPopup(true)}
                  >
                    Create Your Design
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Popup Modal */}
        <AnimatePresence>
          {showPopup && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowPopup(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-gray-900 border border-gray-700 rounded-2xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-white">Your Marketing Design</h3>
                  <button
                    onClick={() => setShowPopup(false)}
                    className="text-gray-400 hover:text-white text-2xl"
                  >
                    ×
                  </button>
                </div>
                
                <p className="text-gray-300 mb-6 text-center">
                  Include your selections when you tell us about yourself in the submission below.
                </p>
                
                <div className="space-y-3">
                  {selectedServices.map(serviceId => {
                    const service = deliStations
                      .flatMap(station => station.services)
                      .find(s => s.id === serviceId);
                    
                    if (!service) return null;
                    
                    return (
                      <div
                        key={serviceId}
                        className="flex items-center gap-4 p-4 bg-gray-800/50 rounded-lg border border-gray-700"
                      >
                        <div className={`w-10 h-10 rounded-lg ${service.color} flex items-center justify-center flex-shrink-0`}>
                          <service.icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="text-white font-semibold">{service.name}</h4>
                          <p className="text-gray-400 text-sm">{service.subtitle}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="mt-8 text-center">
                  <Button 
                    className="premium-button text-lg px-8 py-4"
                    onClick={() => setShowPopup(false)}
                  >
                    Got It!
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default ServiceMenu;

